/*
 * uartechochar.c
 *
 * Created: 08-09-2018 09:43:54
 *  Author: DESD
 */

#include <avr/io.h>
#include <util/delay_basic.h>
#define F_CPU 16000000
char data;

 void uart_init(){
	 UCSR1B=0x18;
	 UCSR1C=0x06;
	 UBRR1L=0x67;	 
 }
 void tx(char da){
	 
	 while(!(UCSR1A & 1<<UDRE1));
	 UDR1=da;
 }
 
 char rx(void){
	 
	 while(!(UCSR1A & 1<<RXC1));
	 data=UDR1;
	 return data;
 }


int main(void)
{
	char d=0;
   while(1)
   {
        uart_init();
		d=rx();
		//elay_ms(1000);
		tx(d);
		
	}	
	return 0;
}